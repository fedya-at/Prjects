﻿using Calculatrice.Interface;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Security.Authentication;

namespace Calculatrice
{
    [TestFixture]
    public class AdvancedCalTest
    {
        private AdvancedCal advancedCal;

        [SetUp]
        public void SetUp()
        {
        }
        //advanced cal
        [TestCase(1, 1, "1", "1", "1")]
        [TestCase(-1, 1, "1", "1", "1")]
        [TestCase(0, 0, "1", "1", "1")]

        public void AbsoluteValue_ValidAuthenticationAndResult(double n1, double expectedResult, string name, string login, string password)
        {
            var stubAuth = Substitute.For<IAuthentication>();
            stubAuth.Authenticate(Arg.Any<User>()).Returns(true);
            advancedCal = new(stubAuth);
            User user = new(name, login, password);
            var result = advancedCal.AbsoluteValue(n1, user);
            Assert.AreEqual(result, expectedResult);
        }
        [TestCase(1)]
        [TestCase(-1)]
        [TestCase(0)]

        public void AbsoluteValue_InvalidAuthenticationAndResult(
            double n1)
        {
            var stubAuth = Substitute.For<IAuthentication >();
            stubAuth.Authenticate(Arg.Any<User>()).Returns(false);
            advancedCal = new(stubAuth);
            var result = Assert.Throws<AuthenticationException>(() => advancedCal.AbsoluteValue(n1, null));
            Assert.IsNotNull(result);

        }
        [TestCase(1)]


        public void Matriciel_validAuthentication(Double n1)
        {
            int result = 1;
            var stubEmailManager = Substitute.For<IEmailManager>();
            var stubAuth = Substitute.For<IAuthentication>();
            stubEmailManager.SendEmail(Arg.Any<string>(), (Arg.Do<int>(arg => result =arg)));
            stubAuth.Authenticate(Arg.Any<User>()).Returns(true);
            advancedCal = new(stubAuth,stubEmailManager);
            advancedCal.Matriciel(n1, null);
            Assert.AreEqual(n1,1);

        }
    }
}