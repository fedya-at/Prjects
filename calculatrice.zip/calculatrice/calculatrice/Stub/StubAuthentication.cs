﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculatrice
{
  public class StubAuthentication:IAuthentication
  {

        public StubAuthentication() 
        {
        }
        public bool Authenticate(User user)
        {
            if (user ==null)
            { return false; }
            return true;
        }
  }
}
