﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculatrice
{
  public class Authentication:IAuthentication
  {
        IDAOUser daouser;
        public Authentication(IDAOUser daouser) 
        {
            this.daouser = daouser;
        }
        public bool Authenticate(User user)
        {
            User userfromdb = daouser.getUser(user);
            Console.WriteLine(userfromdb);
            if (userfromdb ==null)
            { return false; }
            return userfromdb.password == user.password && userfromdb.password==user.password ;
        }
  }
}
