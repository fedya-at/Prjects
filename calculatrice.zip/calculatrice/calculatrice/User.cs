﻿namespace Calculatrice
{
    public class User
    {
        public string name;
        public string login;
        public string password;

        public User(string name, string login, string password)
        {
            this.name = name;
            this.login = login;
            this.password = password;
        }
    }
}