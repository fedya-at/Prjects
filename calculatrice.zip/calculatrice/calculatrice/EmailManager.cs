﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculatrice.Interface;

namespace Calculatrice 
{
    class EmailManager : IEmailManager
    {
        private User _user;
        public EmailManager(User user)
        {
            this._user=user;
        }
        public void SendEmail(string subject, int x)
        {
            
        }
    }
}
