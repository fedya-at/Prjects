﻿using System.Collections.Generic;
using System;
using System.Linq;

namespace Calculatrice
{
    public interface IDAOUser
    {
        public User getUser(User user);

    }
}