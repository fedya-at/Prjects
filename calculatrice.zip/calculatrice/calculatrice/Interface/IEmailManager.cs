﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculatrice.Interface
{
   public interface IEmailManager
    {
        public void SendEmail(string subject, int body);
    }
}
