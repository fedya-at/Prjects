﻿using Calculatrice.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;

namespace Calculatrice
{
    public class AdvancedCal
    {
        IAuthentication authentication;
        IEmailManager EmailManager;
        public AdvancedCal(IAuthentication authentication) 
        {
            this.authentication = authentication;
        }
        public AdvancedCal(IAuthentication authentication,IEmailManager EmailManager)
        {
            this.authentication = authentication;
            this.EmailManager = EmailManager;
        }
        public Double AbsoluteValue(Double x,User user)
        {if (authentication.Authenticate(user))
            {
                Double y = Math.Abs(x);
                return y;
            }
            else throw new AuthenticationException("not Authorized");
        }
        public void Matriciel(Double x, User user)
        {
            if (authentication.Authenticate(user))
            {
                var result = x*x*x;
                EmailManager.SendEmail("result Matriciel",result.ToString());
            }
            else throw new AuthenticationException("not Authorized");
        }
       
    }
}
