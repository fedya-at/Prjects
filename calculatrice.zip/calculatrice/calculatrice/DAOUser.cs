﻿using System.Collections.Generic;
using System;
using System.Linq;

namespace Calculatrice
{
    public class DAOUser:IDAOUser
    {
        List<User> users = new();
        public DAOUser()
        {
            users.Add((new User("1", "1", "1")));

        }
        public User getUser(User user)
        {
           return users.First(u => u.name == user.name);
            
        }


    }
}