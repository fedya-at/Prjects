﻿using System;

namespace calculatrice
{
    class Program
    {public float addition(float x,float y)
        {
            return x + y;
        }
        public float substraction(float x, float y)
        {
            return x - y;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
